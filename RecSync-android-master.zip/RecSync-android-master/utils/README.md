# Panoramic video demo

Uses hujin CLI interface and ffmpeg commands to merge two synchronized smartphone videos, recorded with RecSync.
TODO: describe
